package com.allankenned.unifiedinbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UnifiedInboxApp() }
    }
}

private enum class InboxTab(val label: String) {
    All("Tudo"), Email("E-mail"), Sms("SMS"), Calls("Chamadas")
}

private data class InboxEntry(
    val title: String,
    val subtitle: String,
    val time: String,
    val type: InboxTab,
    val initials: String
)

private val demoEntries = listOf(
    InboxEntry("Bem-vindo ao UnifiedInbox", "Sua caixa unificada começa aqui.", "Agora", InboxTab.All, "U"),
    InboxEntry("E-mail", "Conecte uma conta para ver suas mensagens.", "—", InboxTab.Email, "E"),
    InboxEntry("SMS", "A integração com SMS será adicionada em uma próxima etapa.", "—", InboxTab.Sms, "S"),
    InboxEntry("Chamadas", "O histórico de chamadas será integrado depois.", "—", InboxTab.Calls, "C")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UnifiedInboxApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = InboxTab.entries
    val entries = if (selectedTab == 0) demoEntries else demoEntries.filter { it.type == tabs[selectedTab] }

    MaterialTheme(
        colorScheme = MaterialTheme.colorScheme.copy(
            primary = Color(0xFF6750A4),
            secondary = Color(0xFF625B71),
            background = Color(0xFFF8F7FC),
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF8F7FC),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("UnifiedInbox", fontWeight = FontWeight.Bold)
                            Text("Tudo em um só lugar", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                        }
                    },
                    actions = {
                        Icon(Icons.Default.Search, contentDescription = "Pesquisar", modifier = Modifier.padding(horizontal = 12.dp))
                        Icon(Icons.Default.FilterList, contentDescription = "Filtros", modifier = Modifier.padding(end = 16.dp))
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF8F7FC))
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    tabs.forEachIndexed { index, tab ->
                        val icon = when (tab) {
                            InboxTab.All, InboxTab.Email -> Icons.Default.Email
                            InboxTab.Sms -> Icons.Default.Message
                            InboxTab.Calls -> Icons.Default.Call
                        }
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE7F6)),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Sua comunicação, reunida.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "Uma interface para e-mail, SMS e chamadas. Os conectores reais serão adicionados por etapas.",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
                Text(
                    if (selectedTab == 0) "Visão geral" else tabs[selectedTab].label,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 22.dp, bottom = 10.dp)
                )
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(entries) { entry -> InboxRow(entry) }
                }
            }
        }
    }
}

@Composable
private fun InboxRow(entry: InboxEntry) {
    val accent = when (entry.type) {
        InboxTab.Email -> Color(0xFF6750A4)
        InboxTab.Sms -> Color(0xFF006B5F)
        InboxTab.Calls -> Color(0xFF8B5000)
        InboxTab.All -> Color(0xFF6750A4)
    }
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 1.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(46.dp).clip(CircleShape).background(accent.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Text(entry.initials, color = accent, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(entry.title, fontWeight = FontWeight.SemiBold)
                Text(entry.subtitle, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            Text(entry.time, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        }
    }
}
